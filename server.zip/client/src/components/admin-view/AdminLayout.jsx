import React from 'react'
import { Outlet } from 'react-router-dom'
import Header from './Header'
import Sidebar from './Sidebar'

const AdminLayout = () => {
    return (
        <div>
            <div><Header /></div>
            <div className='flex items-center'>
                <div><Sidebar /></div>
                <Outlet />
            </div>

        </div>
    )
}

export default AdminLayout
