import React from 'react'
import Header from './Header'
import Sidebar from './sidebar'
import { Outlet } from 'react-router-dom'

const Layout = () => {
    return (
        <div>
            <div>
                <Header />

            </div>
            <div className='flex '>
                <Sidebar />
                <Outlet />
            </div>
        </div>
    )
}

export default Layout
