import Layout from './components/auth/Layout'
import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Login from './pages/auth/Login'
import Register from './pages/auth/Register'
import AdminDashboard from './pages/admin-view/AdminDashboard'
import AdminProducts from './pages/admin-view/AdminProducts'
import AdminFeatures from './pages/admin-view/AdminFeatures'
import AdminOrders from './pages/admin-view/AdminOrders'
import Notfound from './pages/not-found/Notfound'
import ShoppingHome from './pages/shopping-view/ShoppingHome'
import ShoppingListing from './pages/shopping-view/ShoppingListing'
import ShoppingAccount from './pages/shopping-view/ShoppingAccount'
import ShoppingCheckout from './pages/shopping-view/ShoppingCheckout'
import Unauth from './pages/unauth/Unauth'
import CheckAuth from './pages/comman/Checkauth'
import AdminLayout from './components/admin-view/AdminLayout'

const App = () => {
  
  return (
    <>
    <Routes>
      <Route path='/auth' element={<Layout/>}>
          <Route path='login' element={<Login/>}/>
          <Route path='register' element={<Register/>}/>
      </Route>
      <Route path='/admin' element={ <AdminLayout/>} >
        <Route path='dashboard' element={<AdminDashboard/>}/>
        <Route path='products' element={<AdminProducts/>}/>
        <Route path='features' element={<AdminFeatures/>}/>
        <Route path='orders' element={<AdminOrders/>}/>
      </Route>
      <Route path='/shop' element={<CheckAuth/>}>
          <Route path='home' element={<ShoppingHome/>}/>
          <Route path='listing' element={<ShoppingListing/>}/>
          <Route path='account' element={<ShoppingAccount/>}/>
          <Route path='checkout' element={<ShoppingCheckout/>}/>
      </Route>
      <Route path='*' element={<Notfound/>}/>
      <Route path='/unauth-page' element={<Unauth/>}/>
    </Routes>
    </>
  )
}

export default App
